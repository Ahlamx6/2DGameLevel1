using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFolllow : MonoBehaviour
{
   
    public Transform target;
    public float smoothSpeed = 0.125f;
    public Vector3 locationOffset;
    

    void Update()
    {
        Vector3 desiredPosition = target.position + target.rotation * locationOffset;
        desiredPosition = new Vector3(desiredPosition.x, 0, -10f);
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;
    }
}
